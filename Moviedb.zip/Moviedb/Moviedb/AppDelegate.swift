//
//  AppDelegate.swift
//  MovieDB
//
//  Created by Uriel Peña Estel on 30/04/22.
//

import UIKit

@main
class AppDelegate: UIResponder, UIApplicationDelegate
{
    public var window: UIWindow?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool
    {
        self.window =   UIWindow(frame: UIScreen.main.bounds)
        self.window?.rootViewController =   UINavigationController(rootViewController: MovieLoginMain.createModule())
        self.window?.makeKeyAndVisible()
        
        return true
    }
}

